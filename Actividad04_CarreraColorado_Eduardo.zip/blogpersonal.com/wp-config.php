<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_blogpersonal' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'xKRRER@0910x' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'P?/:i^pxA%s$SlWugl@(=T@]hwlj62m=vq8 m^WT[/nYH3t`>D+|&CZFCZdq3&fX' );
define( 'SECURE_AUTH_KEY',  '?ypE)emla:<W~|@H]M<01fom-ddtEXf*q]vG6)t_y<T`$+ZJ0FxcU2Z;-cJ2N{*L' );
define( 'LOGGED_IN_KEY',    'ZRU$rok+^swCD|5`nCg$A9|ZZ;_y55s|y(2|~eMMZ0AQYz-R3#ub=0+psi`BC<.a' );
define( 'NONCE_KEY',        '$tf?gF786IkGofI.8})inv.hH>3PPm5tsAZ3rKi@?s{_jA77:PrX}2<M#F3$i#=U' );
define( 'AUTH_SALT',        'sa8bAt4(9v3:r|$C<t!;41^0;oy::yWFUG,$!8cY]jDuP<]8syRH3yJ.@$8S}dTC' );
define( 'SECURE_AUTH_SALT', '~Fs>yC}x]?Z;{~y6TG!zcyfkFxhx2Ob]X-_@)zA?>AI.zzkK!jX TO{gG~;vCBpO' );
define( 'LOGGED_IN_SALT',   'Oq]R>TniW?=KN!O`Gt6JKdTqx<D1i^Cgein!=e0frA0M#%St!<XqVYv0B05=&/d(' );
define( 'NONCE_SALT',       '~.;iH7U+_8| Fmh-WtNlq&x&.#C2w>y2>0:OQ-AC+T}Fw$|O7350#M>TAZ1&;n[&' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
